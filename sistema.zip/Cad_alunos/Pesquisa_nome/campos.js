// JavaScript Document
                // Nome1******************************************************************************************
$(document).ready(function(){
				//Ao digitar executar essa função
				$("#nome").focus().autocomplete("exemplo03_nomes.asp",{
					  minChars: 1 //Número mínimo de caracteres para aparecer a lista
					, matchContains: true //Aparecer somente os que tem relação ao valor digitado
					, scrollHeight: 220 //Altura da lista dos nomes
					, selectFirst: true //Vim o primeiro da lista selecionado
					, mustMatch: true //Caso não existir na lista, remover o valor
					, delay: 0 //Tempo para aparecer a lista para 0, por padrão vem 200
				});
								
				//Quando selecionar valor pegar retorno. O retorno nesse caso são: Nome|Código
				$("#nome").result(function(event, retorno) {
					if (retorno==undefined)
						$("#data_nascimento","#cpf").val("") ;
												
					else
						$("#codigo").val(retorno[1]);
						$("#codigo1").val(retorno[2]);
						
				});				
			});
			// Nome2**********************************************************************************************

					$(document).ready(function(){
				//Ao digitar executar essa função
				$("#nome1").focus().autocomplete("exemplo03_nomes.asp",{
					  minChars: 1 //Número mínimo de caracteres para aparecer a lista
					, matchContains: true //Aparecer somente os que tem relação ao valor digitado
					, scrollHeight: 220 //Altura da lista dos nomes
					, selectFirst: true //Vim o primeiro da lista selecionado
					, mustMatch: true //Caso não existir na lista, remover o valor
					, delay: 0 //Tempo para aparecer a lista para 0, por padrão vem 200
				});
								
				//Quando selecionar valor pegar retorno. O retorno nesse caso são: Nome|Código
				$("#nome1").result(function(event, retorno) {
					if (retorno==undefined)
						$("#data_nascimento","#cpf").val("") ;
												
					else
						$("#codigo2").val(retorno[1]);
						$("#codigo3").val(retorno[2]);
				});				
			});
			// Nome3************************************************************************************************
			$(document).ready(function(){
				//Ao digitar executar essa função
				$("#nome3").focus().autocomplete("exemplo03_nomes.asp",{
					  minChars: 1 //Número mínimo de caracteres para aparecer a lista
					, matchContains: true //Aparecer somente os que tem relação ao valor digitado
					, scrollHeight: 220 //Altura da lista dos nomes
					, selectFirst: true //Vim o primeiro da lista selecionado
					, mustMatch: true //Caso não existir na lista, remover o valor
					, delay: 0 //Tempo para aparecer a lista para 0, por padrão vem 200
				});
								
				//Quando selecionar valor pegar retorno. O retorno nesse caso são: Nome|Código
				$("#nome3").result(function(event, retorno) {
					if (retorno==undefined)
						$("#data_nascimento","#cpf").val("") ;
												
					else
						$("#codigo4").val(retorno[1]);
						$("#codigo5").val(retorno[2]);
				});				
			});
			// Nome4************************************************************************************************
			$(document).ready(function(){
				//Ao digitar executar essa função
				$("#nome4").focus().autocomplete("exemplo03_nomes.asp",{
					  minChars: 1 //Número mínimo de caracteres para aparecer a lista
					, matchContains: true //Aparecer somente os que tem relação ao valor digitado
					, scrollHeight: 220 //Altura da lista dos nomes
					, selectFirst: true //Vim o primeiro da lista selecionado
					, mustMatch: true //Caso não existir na lista, remover o valor
					, delay: 0 //Tempo para aparecer a lista para 0, por padrão vem 200
				});
								
				//Quando selecionar valor pegar retorno. O retorno nesse caso são: Nome|Código
				$("#nome4").result(function(event, retorno) {
					if (retorno==undefined)
						$("#data_nascimento","#cpf").val("") ;
												
					else
						$("#codigo6").val(retorno[1]);
						$("#codigo7").val(retorno[2]);
				});				
			});
			// Nome5************************************************************************************************
			$(document).ready(function(){
				//Ao digitar executar essa função
				$("#nome5").focus().autocomplete("exemplo03_nomes.asp",{
					  minChars: 1 //Número mínimo de caracteres para aparecer a lista
					, matchContains: true //Aparecer somente os que tem relação ao valor digitado
					, scrollHeight: 220 //Altura da lista dos nomes
					, selectFirst: true //Vim o primeiro da lista selecionado
					, mustMatch: true //Caso não existir na lista, remover o valor
					, delay: 0 //Tempo para aparecer a lista para 0, por padrão vem 200
				});
								
				//Quando selecionar valor pegar retorno. O retorno nesse caso são: Nome|Código
				$("#nome5").result(function(event, retorno) {
					if (retorno==undefined)
						$("#data_nascimento","#cpf").val("") ;
												
					else
						$("#codigo8").val(retorno[1]);
						$("#codigo9").val(retorno[2]);
				});				
			});
			// Nome6************************************************************************************************
			$(document).ready(function(){
				//Ao digitar executar essa função
				$("#nome6").focus().autocomplete("exemplo03_nomes.asp",{
					  minChars: 1 //Número mínimo de caracteres para aparecer a lista
					, matchContains: true //Aparecer somente os que tem relação ao valor digitado
					, scrollHeight: 220 //Altura da lista dos nomes
					, selectFirst: true //Vim o primeiro da lista selecionado
					, mustMatch: true //Caso não existir na lista, remover o valor
					, delay: 0 //Tempo para aparecer a lista para 0, por padrão vem 200
				});
								
				//Quando selecionar valor pegar retorno. O retorno nesse caso são: Nome|Código
				$("#nome6").result(function(event, retorno) {
					if (retorno==undefined)
						$("#data_nascimento","#cpf").val("") ;
												
					else
						$("#codigo10").val(retorno[1]);
						$("#codigo11").val(retorno[2]);
				});				
			});
			// Nome7************************************************************************************************
			$(document).ready(function(){
				//Ao digitar executar essa função
				$("#nome7").focus().autocomplete("exemplo03_nomes.asp",{
					  minChars: 1 //Número mínimo de caracteres para aparecer a lista
					, matchContains: true //Aparecer somente os que tem relação ao valor digitado
					, scrollHeight: 220 //Altura da lista dos nomes
					, selectFirst: true //Vim o primeiro da lista selecionado
					, mustMatch: true //Caso não existir na lista, remover o valor
					, delay: 0 //Tempo para aparecer a lista para 0, por padrão vem 200
				});
								
				//Quando selecionar valor pegar retorno. O retorno nesse caso são: Nome|Código
				$("#nome7").result(function(event, retorno) {
					if (retorno==undefined)
						$("#data_nascimento","#cpf").val("") ;
												
					else
						$("#codigo12").val(retorno[1]);
						$("#codigo13").val(retorno[2]);
				});				
			});
			// Nome8************************************************************************************************
			$(document).ready(function(){
				//Ao digitar executar essa função
				$("#nome7").focus().autocomplete("exemplo03_nomes.asp",{
					  minChars: 1 //Número mínimo de caracteres para aparecer a lista
					, matchContains: true //Aparecer somente os que tem relação ao valor digitado
					, scrollHeight: 220 //Altura da lista dos nomes
					, selectFirst: true //Vim o primeiro da lista selecionado
					, mustMatch: true //Caso não existir na lista, remover o valor
					, delay: 0 //Tempo para aparecer a lista para 0, por padrão vem 200
				});
								
				//Quando selecionar valor pegar retorno. O retorno nesse caso são: Nome|Código
				$("#nome8").result(function(event, retorno) {
					if (retorno==undefined)
						$("#data_nascimento","#cpf").val("") ;
												
					else
						$("#codigo14").val(retorno[1]);
						$("#codigo15").val(retorno[2]);
				});				
			});